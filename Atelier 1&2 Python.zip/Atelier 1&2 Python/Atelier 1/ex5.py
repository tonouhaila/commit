def cpt(x):
    if x<=10:
        return 1
    else :
        return cpt(x)/10
nbr=0

n=int(input("donner n : "))

while (n != 0) :
    n=cpt(n)
    nbr=nbr+1

print("resultat : ",nbr)