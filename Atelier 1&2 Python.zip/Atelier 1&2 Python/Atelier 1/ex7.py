def inver(x):
   a=""
   for i in x :
        a=i+a
   return a
n=input("donner un mot :")
print("l'inverse de",n,"est : ",inver(n))





