def somrecur(n):
    
    if n==0:

     return 0
    else :
     return (n+somrecur(n-1))

n=int(input("entrer n:"))
somrecur(n)
print("som=",somrecur(n))
