
def fibonnacci(x):
    if x<=1:
        return x
    else:
        return fibonnacci(x-1)+fibonnacci(x-2)
n=int(input("Donner le nombre de termes de la série de fibonacci à afficher: "))
print("les" ,n,"premières termes de la série de fibonacci : ")
for i in range(n):
 print(fibonnacci(i))
  