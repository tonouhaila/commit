def fact(x):
  if x == 1:
    return 1
  else:
   return (x * fact(x-1))



   
n=int(input("Enrter la valeur de n:"))
S=0
for i in range(1,n+1):
    S+=i/fact(i)
print(" la somme est ",S)

   


