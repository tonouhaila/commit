def cmpt(x):
    n=1
    if x == 0:
        return 0
    else:
        x=int(x/10)
        return 1+cmpt(x)

a=int(input("donner un nombre : "))
print("le nombre de chiffres est:",cmpt(a))
