l=[]
n=int(input("loguer l1  "))
for i in range(n):
    x=int(input(""))
    l.append(x)
print(l)
b=0
n=len(l)
m=n//3
print("la liste diviser en 3 morceaux avec l'inverse de chaque morceau : s")
for i in range(0,n,m):
    b=b+m
    l[i]=l[i:b]
    l[i]=list(range(b,i,-1))
    print(l[i])
    