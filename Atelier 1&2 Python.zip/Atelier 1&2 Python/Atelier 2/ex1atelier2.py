l1=[]
n=int(input("loguer l1 : "))
for i in range(n):
    x=int(input(""))
    l1.append(x)
l2=[]
m=int(input("loguer l2 : "))
for i in range(m):
    y=int(input(""))
    l2.append(y)
print(l1)
print(l2)
l3=[]
for i in range(n):
    if i%2!=0 :
        imp=l1[i]
        l3.append(imp)
for i in range(m):
    if i%2==0:
        pair=l2[i]  
        l3.append(pair)
print(l3)



